<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class pet extends Model
{
    //definir propiedades
    public $pets;

    public function render()
    {
        
    }
    
}